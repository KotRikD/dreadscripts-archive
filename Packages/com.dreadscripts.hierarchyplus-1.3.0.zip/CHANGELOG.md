(v1.3.0)
--------
- [Feature] Added labels for GameObject Tag & Layer. Customizable in settings.
- [Feature] Added Custom Icons for VRC Constraints. Thanks to @JustBuddy
- [Misc] Set minimal Unity version

(v1.2.1)
--------
- [Feature] Added an option to enable/disable Drag-Toggle
- [Fix] Fixed Drag-Toggle sometimes affecting adjacent icons
- [Fix] Fixed GameObject icons not being used in Unity 2022
- [Fix] Fixed Refresh Icons button not doing anything and instead constantly refreshing while settings window was open.
- [UI] Revamped the settings window
- [Misc] Thanks to @JustBuddy for various help.

(v1.2.0)
--------
- [Feature] You can now click drag on components to toggle them.
- [Improvement] Added various icons for widely used community scripts. Thanks to @JustBuddy
- [Improvement] Custom Icons can now be placed in sub-directories of the CustomIcons folder and have been organized.

(v1.1.0)
--------
- [Feature] Added X Offset option to icons in settings.
- [Misc] Changed license to GPL-3.0 and shared the source code.
- [Misc] Added this changelog