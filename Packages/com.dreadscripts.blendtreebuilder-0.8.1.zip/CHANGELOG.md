(v0.8.1)
--------
- [Fix] Added assembly definition which allows the package to actually compile
- [Misc] Defined minimal unity version

(v0.8.0)
--------
- [Improvement] Migrated to VPM Format

(v0.7.0)
--------
- [Feature] Can now handle layers with exclusive toggles
- [Feature] Can now handle states with motion time
- [Feature] Can now handle layers with a single state
- [Feature/Fix] Added automatic fix of Unity's stupid native bug where, in DBTs, the total length of all clips lengths added together is the length of all clips.
- [UI] Added layer index to optimization window
- [UI] Other changes to make it clearer and cleaner
- [Change] Warnings will now also disable the optimizable layers by default

(v0.5.2)
--------
- [Fix] Fix incorrect error warning for missing parameter

(v0.5.1)
--------
- [UI] Add error warning for Statemachine Behaviours
- [UI] Add warning for standardized conditions

(v0.5.0)
--------
- Initial Release