v1.6.1
------
- [Fix] Added assembly definition which allows the package to actually compile
- [Misc] Defined minimal unity version

v1.6.0
------
- [Improvement] Updated VPM Format

v1.5.1
------
- [Feature] Added 'Write Defaults' Option for making a toggle
- [Improvement] Migrated to VPM Format

v1.5.0
------
- [Feature] Added VRC support to quickly add a toggle
