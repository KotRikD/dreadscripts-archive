# CopyCutPaste
Adds 3 much needed buttons to Unity assets: Copy, Cut, and Paste. Does what's expected.

### [Download From Here](https://vpm.dreadscripts.com/)

### Thank You
If you enjoy CopyCutPaste, please consider [supporting me ♡](https://ko-fi.com/Dreadrith)!