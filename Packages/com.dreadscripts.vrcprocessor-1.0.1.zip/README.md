# VRCProcessor
Automatically sets valid models to Humanoid and other usual settings upon import.

## Features
- Sets Normals to import
- Enables Read/Write
- Sets Humanoid Rig for Humanoid models
- Removes Upper Chest bone
- Removes Jaw bone if invalid

### Thank you
If you enjoy VRCProcessor, please consider [supporting me ♡](https://ko-fi.com/Dreadrith)!